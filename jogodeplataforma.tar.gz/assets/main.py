import pygame
import sys
import asyncio
import math
import random
import time
from pygame import Rect

pygame.init()
pygame.mixer.init()

WIDTH, HEIGHT, TITLE = 800, 600, "Shadow Knight Adventure"
screen_surface = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption(TITLE)

_image_cache = {}
class ScreenWrap:
    def fill(self, color):
        screen_surface.fill(color)
    def blit(self, img_name, pos):
        if img_name not in _image_cache:
            try:
                _image_cache[img_name] = pygame.image.load(f"images/{img_name}.png").convert_alpha()
            except:
                try:
                    _image_cache[img_name] = pygame.image.load(f"images/{img_name}.gif").convert_alpha()
                except:
                    _image_cache[img_name] = pygame.Surface((32,32), pygame.SRCALPHA)
        screen_surface.blit(_image_cache[img_name], pos)
        
    class draw:
        @staticmethod
        def filled_rect(rect, color):
            pygame.draw.rect(screen_surface, color, rect)
        @staticmethod
        def rect(rect, color):
            pygame.draw.rect(screen_surface, color, rect, 1)
        @staticmethod
        def filled_circle(pos, r, color):
            pygame.draw.circle(screen_surface, color, pos, r)
        @staticmethod
        def text(text, center, fontsize, color, shadow=None):
            font = pygame.font.SysFont(None, fontsize)
            surf = font.render(text, True, color)
            r = surf.get_rect(center=center)
            screen_surface.blit(surf, r)

screen = ScreenWrap()

class Actor:
    def __init__(self, image_name, pos):
        self._image_name = image_name
        self.rect = pygame.Rect(0, 0, 0, 0)
        self._surf = None
        self._load(image_name)
        self.rect.center = pos
        
    def _load(self, name):
        if name not in _image_cache:
            try:
                _image_cache[name] = pygame.image.load(f"images/{name}.png").convert_alpha()
            except:
                try:
                    _image_cache[name] = pygame.image.load(f"images/{name}.gif").convert_alpha()
                except:
                    # fallback transparent surface if not found
                    _image_cache[name] = pygame.Surface((32,32), pygame.SRCALPHA)
        self._surf = _image_cache[name]
        self.rect.width = self._surf.get_width()
        self.rect.height = self._surf.get_height()
        
    @property
    def image(self): return self._image_name
    @image.setter
    def image(self, name):
        self._image_name = name
        self._load(name)

    @property
    def x(self): return self.rect.centerx
    @x.setter
    def x(self, val): self.rect.centerx = val
    @property
    def y(self): return self.rect.centery
    @y.setter
    def y(self, val): self.rect.centery = val
    @property
    def left(self): return self.rect.left
    @left.setter
    def left(self, val): self.rect.left = val
    @property
    def right(self): return self.rect.right
    @right.setter
    def right(self, val): self.rect.right = val
    @property
    def top(self): return self.rect.top
    @top.setter
    def top(self, val): self.rect.top = val
    @property
    def bottom(self): return self.rect.bottom
    @bottom.setter
    def bottom(self, val): self.rect.bottom = val
    @property
    def centerx(self): return self.rect.centerx
    @property
    def centery(self): return self.rect.centery
    @property
    def width(self): return self.rect.width
    @property
    def height(self): return self.rect.height
    @property
    def center(self): return self.rect.center
    @center.setter
    def center(self, val): self.rect.center = val
    
    def colliderect(self, other):
        if hasattr(other, 'rect'):
            return self.rect.colliderect(other.rect)
        return self.rect.colliderect(other)
        
    def draw(self):
        if self._surf:
            screen_surface.blit(self._surf, self.rect)

_sound_cache = {}
def play_sfx(n):
    if not music_enabled: return
    if n not in _sound_cache:
        try:
            _sound_cache[n] = pygame.mixer.Sound(f"sounds/{n}.wav")
        except:
            return
    _sound_cache[n].play()

MENU, PLAYING, GAME_OVER, VICTORY = "menu", "playing", "game_over", "victory"

LEVELS = [
    {
        "player_start": (50, 500),
        "platforms": [
            Rect(0, 560, 800, 40),
            Rect(500, 420, 150, 20),
            Rect(350, 320, 150, 20),
            Rect(600, 220, 150, 20),
            Rect(200, 150, 250, 20)
        ],
        "enemies": [
            {"x": 400, "y": 560, "range": 150},
            {"x": 580, "y": 420, "range": 60},
            {"x": 320, "y": 150, "range": 100}
        ],
        "goal": (350, 130)
    },
    {
        "player_start": (50, 500),
        "platforms": [
            Rect(0, 560, 800, 40),
            Rect(150, 450, 100, 20),
            Rect(50, 350, 100, 20),
            Rect(250, 250, 100, 20),
            Rect(450, 200, 100, 20),
            Rect(650, 150, 100, 20),
            Rect(650, 450, 150, 20),
            Rect(400, 350, 100, 20)
        ],
        "enemies": [
            {"x": 400, "y": 560, "range": 200},
            {"x": 200, "y": 450, "range": 40},
            {"x": 100, "y": 350, "range": 40},
            {"x": 300, "y": 250, "range": 40},
            {"x": 725, "y": 450, "range": 60},
            {"x": 450, "y": 350, "range": 40}
        ],
        "goal": (700, 130)
    }
]

current_state, music_enabled = MENU, True
current_level_idx = 0
platforms = []
goal_pos = (0,0)
game_objects, player, particles = [], None, []

class Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-2, 2)
        self.vy = random.uniform(-1, 3)
        self.life = 20
        self.max_life = 20
        self.color = random.choice([(200, 200, 200), (150, 150, 150), (255, 255, 255)])

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1

    def draw(self):
        if self.life > 0:
            r = max(1, int(4 * (self.life / self.max_life)))
            screen.draw.filled_circle((self.x, self.y), r, self.color)

class Entity:
    def __init__(self, pos, idle_r, idle_l, walk_r, walk_l):
        self.actor = Actor(idle_r[0], pos)
        self.idle_r, self.idle_l = idle_r, idle_l
        self.walk_r, self.walk_l = walk_r, walk_l
        self.current, self.idx, self.timer = idle_r, 0, 0
        self.facing = "right"

    def animate(self, moving):
        if self.facing == "right": f = self.walk_r if moving else self.idle_r
        else: f = self.walk_l if moving else self.idle_l
        
        if self.current != f: 
            self.current, self.idx, self.timer = f, 0, 0
            
        self.timer += 1
        if self.timer >= 8:
            self.timer, self.idx = 0, (self.idx + 1) % len(self.current)
        self.actor.image = self.current[self.idx]

    def draw(self): 
        self.actor.draw()

class Player(Entity):
    def __init__(self, x, y):
        super().__init__((x, y), ['hero_idle_1'], ['hero_idle_left'], 
                         ['hero_run_1'], ['hero_run_left'])
        self.vx = self.vy = 0
        self.ground = False
        
    def update(self, keys):
        self.vx = 0
        if keys[pygame.K_LEFT]: self.vx, self.facing = -5, "left"
        elif keys[pygame.K_RIGHT]: self.vx, self.facing = 5, "right"
        
        if (keys[pygame.K_UP] or keys[pygame.K_SPACE]) and self.ground:
            self.vy, self.ground = -13, False
            play_sfx('sfx_jump_09')
            for _ in range(10):
                particles.append(Particle(self.actor.centerx, self.actor.bottom))
                
        self.vy += 0.6
        
        self.actor.x += self.vx
        self.actor.left = max(0, min(self.actor.left, WIDTH - self.actor.width))
        
        self.actor.y += self.vy
        self.ground = False
        for p in platforms:
            if self.actor.colliderect(p) and self.vy > 0:
                if self.actor.bottom - self.vy <= p.top + 10:
                    self.actor.bottom = p.top
                    self.vy = 0
                    self.ground = True
                    
        self.animate(self.vx != 0)

class Enemy(Entity):
    def __init__(self, x, y, r):
        super().__init__((x, y), ['enemy_walk_1', 'enemy_walk_2'], ['enemy_walk_1left', 'enemy_walk_2left'], 
                         ['enemy_walk_1', 'enemy_walk_2'], ['enemy_walk_1left', 'enemy_walk_2left'])
        self.start_x, self.range, self.dir = x, r, 1
        self.actor.bottom = y
        
    def update(self):
        self.actor.x += 2 * self.dir
        self.facing = "right" if self.dir > 0 else "left"
        if abs(self.actor.x - self.start_x) > self.range: self.dir *= -1
        self.animate(True)

def init_game(level_idx=0):
    global player, game_objects, current_state, particles, platforms, goal_pos, current_level_idx
    
    current_level_idx = level_idx
    lvl_data = LEVELS[current_level_idx]
    
    platforms = lvl_data["platforms"]
    goal_pos = lvl_data["goal"]
    
    px, py = lvl_data["player_start"]
    player = Player(px, py)
    
    game_objects = []
    for e in lvl_data["enemies"]:
        game_objects.append(Enemy(e["x"], e["y"], e["range"]))
        
    particles = []
    current_state = PLAYING

def draw():
    screen.fill((30, 30, 45))
    if current_state == MENU:
        draw_txt(TITLE, 60, -150)
        draw_btn("START GAME", 250, "darkgreen", "green")
        draw_btn("SOUND: " + ("ON" if music_enabled else "OFF"), 330, "steelblue", "skyblue")
        draw_btn("EXIT", 410, "darkred", "red")
    elif current_state == PLAYING:
        try: screen.blit('background', (0,0))
        except: pass
        
        screen.draw.text(f"Level {current_level_idx + 1}", center=(50, 20), fontsize=30, color="white")
        
        for p in platforms:
            screen.draw.filled_rect(p, (80, 55, 30))
            screen.draw.filled_rect(Rect(p.left, p.top, p.width, 5), (50, 150, 50))
            screen.draw.filled_rect(Rect(p.left, p.bottom-5, p.width, 5), (40, 25, 10))
            
        goal_y = goal_pos[1] + math.sin(time.time() * 5) * 5
        screen.draw.filled_circle((goal_pos[0], goal_y), 12, "orange")
        screen.draw.filled_circle((goal_pos[0], goal_y), 8, "yellow")
        
        for part in particles: part.draw()
        for o in game_objects: o.draw()
        player.draw()
        
    else:
        msg = "VICTORY!" if current_state == VICTORY else "GAME OVER"
        c1 = "gold" if current_state == VICTORY else "red"
        draw_txt(msg, 80, -30, c1)
        draw_txt("Click to Restart", 40, 50, "white")
    
    pygame.display.flip()

def draw_txt(t, s, y, c="white"):
    screen.draw.text(t, center=(WIDTH//2+2, HEIGHT//2+y+2), fontsize=s, color="black")
    screen.draw.text(t, center=(WIDTH//2, HEIGHT//2+y), fontsize=s, color=c)

def draw_btn(t, y, bg_color, border_color):
    r = Rect(WIDTH//2-120, y-25, 240, 50)
    screen.draw.filled_rect(r, bg_color)
    screen.draw.rect(r, border_color)
    screen.draw.text(t, center=r.center, fontsize=30, color="white")

def update(keys):
    global current_state, particles, current_level_idx
    if current_state == PLAYING:
        player.update(keys)
        for o in game_objects:
            o.update()
            dist = math.hypot(player.actor.centerx - o.actor.centerx, player.actor.centery - o.actor.centery)
            if dist < 30: current_state = GAME_OVER
            
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
            
        dist_goal = math.hypot(player.actor.centerx - goal_pos[0], player.actor.centery - goal_pos[1])
        if dist_goal < 30: 
            if current_level_idx + 1 < len(LEVELS):
                init_game(current_level_idx + 1)
            else:
                current_state = VICTORY

async def main():
    global current_state, music_enabled
    clock = pygame.time.Clock()
    
    while True:
        keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                if current_state == MENU:
                    if Rect(280, 225, 240, 50).collidepoint(pos): init_game(0)
                    elif Rect(280, 305, 240, 50).collidepoint(pos):
                        music_enabled = not music_enabled
                    elif Rect(280, 385, 240, 50).collidepoint(pos):
                        pygame.quit()
                        sys.exit()
                elif current_state in (GAME_OVER, VICTORY): 
                    current_state = MENU

        update(keys)
        draw()
        clock.tick(60)
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())
